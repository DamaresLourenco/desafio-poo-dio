Desafio DIO: Programação Orientada a Objetos com Java - Banco Digital

Como executar:
1. Abra uma IDE (IntelliJ, Eclipse ou VS Code com extensão Java).
2. Copie os arquivos da pasta 'src' para seu projeto Java.
3. Compile e execute a classe Main.java.
4. Veja o extrato sendo impresso no console com base na simulação de depósito e transferência.

Desenvolvido com base no repositório: https://github.com/cami-la/desafio-poo-dio